import UIKit

enum StatusCode: Int {
    case success = 200
    case unauthorized = 401
    case forbidden = 403
    case notFound = 404
}

func prettyPrint(value: StatusCode.RawValue) -> String? {
    switch value {
    case 200:
        return "200: Success"
    case 401:
        return "401: Unauthorized"
    case 403:
        return "403: Forbidden"
    case 404:
        return "404: Not Found"
    default:
        return "Error: No Code Found"
    }
}
