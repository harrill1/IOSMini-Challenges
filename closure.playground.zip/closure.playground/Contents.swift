import UIKit

struct MathOperation {
    var units: String
    var operation: (Double, Double) -> Double = {
        value1, value2 in
        var number: Double = value1
        number *= value2
        return number
        
    }
    
    init?(units: String) {
        if (units.count > 0){
            self.units = units
        } else {
            return nil
        }
        
    }
}
